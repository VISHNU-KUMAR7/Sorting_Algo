#include <stdio.h>
#include <stdlib.h>

int main()
{
    int A[9] = {2,5,23,6,8,5,3,45,24};
    int len ,i;
    len = sizeof A/sizeof *A;
    quickSort(A,0,len-1);
    for (i =0;i<len;i++)
    {
        printf("%d ",A[i]);
    }
}
int partion(int A[],int lb,int up)
{
    int start,pivot,end,temp;
    start = lb;
    end = up;
    pivot = A[lb];
    while(start<end)
    {
        while(A[start]<=pivot)
        {
            start++;
        }
        while(A[end]>pivot)
        {
            end--;
        }
        if(start<end)
        {
            temp = A[start];
            A[start] = A[end];
            A[end] = temp;
        }
    }
   temp = A[end];
    A[end] = A[lb];
    A[lb] = temp;
    return end;
}
quickSort(int A[],int lb,int up)
{
    int loc;
    if(lb<up)
    {
        loc = partion(A,lb,up);
        quickSort(A,lb,loc-1);
        quickSort(A,loc+1,up);
    }
}
