#include <stdio.h>
#include <stdlib.h>

int main()
{
    int A[9] = {47,63,45,71,10,48,93,65,48};
    int len,i;
    len = sizeof A/sizeof *A;
    insertionSort(A,len);
    for (i = 0;i<len;i++)
        printf("%d ",A[i]);
}
insertionSort(int A[],int n)
    {
        int i,j,temp;
        for (i = 1;i<n;i++)
        {
            temp = A[i];
            j = i-1;
            while(j>=0&&A[j]>temp)
            {
                A[j+1] = A[j];
                j--;
            }
            A[j+1]= temp;
        }
    }
