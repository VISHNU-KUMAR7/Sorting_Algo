#include <stdio.h>
#include <stdlib.h>

int main()
{
    int A[7] = {47,63,42,52,98,10,75};
    int len,i;
    len = sizeof A/sizeof *A;
    selectionSort(A,len);
    for(i =0;i<len;i++)
        printf("%d ",A[i]);
}
selectionSort(int A[],int n)
{
    int temp,min,i,j;
    for(i=0;i<n-1;i++)
    {
        min = i;
        for(j = i+1;j<n;j++)
        {
            if(A[j]<A[min])
                min = j;
        }
        if (i!=min)
        {
            temp = A[i];
            A[i] = A[min];
            A[min] = temp;
        }
    }
}
